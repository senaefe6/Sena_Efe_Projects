import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code NatualNumber}.
 *
 * @author Sena Efe
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     ** Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";

        NaturalNumber result = new NaturalNumber2(0);
        // Base case: If the expression is a number, return its integer value
        if (exp.label().equals("number")) {
            result.copyFrom(new NaturalNumber2(exp.attributeValue("value")));
        } else {
            XMLTree leftChild = exp.child(0);
            XMLTree rightChild = exp.child(1);

            // Recursively evaluate left and right children
            NaturalNumber leftValue = evaluate(leftChild);
            NaturalNumber rightValue = evaluate(rightChild);

            if (exp.label().equals("plus")) {
                result.copyFrom(leftValue); // Copy leftValue to result
                result.add(rightValue); // Add rightValue to result
            } else if (exp.label().equals("minus")) {
                result.copyFrom(leftValue);
                result.subtract(rightValue);
            } else if (exp.label().equals("times")) {
                result.copyFrom(leftValue);
                result.multiply(rightValue);
            } else if (exp.label().equals("divide")) {
                if (rightValue.isZero()) {
                    Reporter.fatalErrorToConsole(
                            "Division by zero is not allowed.");
                    System.exit(0);
                }
                result.copyFrom(leftValue);
                result.divide(rightValue);
            } else {
                Reporter.fatalErrorToConsole(
                        "Unknown operator: " + exp.label());
                System.exit(1);
            }

        }
        return result;

    }

    /**
     * Prints the given error message to the console and terminates the
     * application.
     *
     * @param msg
     *            the error message
     * @ensures [msg is printed to the console and the application terminates]
     */

    public static void fatalErrorToConsole(String msg) {
        assert msg != null : "Violation of: msg is not null";
        //throw new RuntimeException(msg);
        System.exit(1);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        //enter the whole file directory
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            NaturalNumber result = evaluate(exp.child(0));
            out.println(result);
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}